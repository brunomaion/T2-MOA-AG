#include <iostream>
#include <cmath>
#include "Randomc.h"
#include "AGBin.h"
#include "Utils.h"
#include "Singleton.h"

using namespace std;

//----------------------------------------------------------------------------------------------
// Rotina para mutar aleatoriamente os alelos de um Gene. Recebe como par�metro a taxa de
// muta��o
//----------------------------------------------------------------------------------------------
void Gene::Mutate(const float &TxMut){
int i;
Singleton *S = S->Instance();

   //Muta��o aplicada em um alelo de cada gene
   if (S->Rnd->Random() < TxMut){
      i = S->Rnd->IRandom(0, Alelos.size());
      if (Alelos[i] == '0') Alelos[i] = '1';
      else Alelos[i] = '0';
   }
}

//----------------------------------------------------------------------------------------------
// Rotina para efetuar o crossover em um ponto entre genes. Recebe como par�metros a taxa de
// crossover e o cromossomo com o qual o cromossomo corrente dever� compartilhar bits
//----------------------------------------------------------------------------------------------
void Gene::Crossover(const float &TxCruz, const Gene &Gene2){
int i, PCorte;
string Tmp1, Tmp2;
Singleton *S = S->Instance();

   if (S->Rnd->Random() < TxCruz){
		PCorte = S->Rnd->IRandom(0, Tamanho - 1);

		for (i = PCorte; i < Tamanho; ++i){
			Alelos[i] = Gene2.Alelos[i];
		}
	}
}

//----------------------------------------------------------------------------------------------
// Calcula o equivalente decimal do gene e seu valor escalonado
//----------------------------------------------------------------------------------------------
void Gene::Eval(){
int i, ValorInt;
	Valor = 0;
	ValorInt = 0;

	for (i = 0; i < Tamanho; ++i){
      if (Alelos[i] == '1') ValorInt += pow (2, Tamanho - (i + 1));
	}

	Valor = Min + (ValorInt/(pow(2, Tamanho)-1)) * (Max - Min);
}

//----------------------------------------------------------------------------------------------
// Destrutor do Gene - Zera as propriedades do Gene
//----------------------------------------------------------------------------------------------
Gene::~Gene(){
	Tamanho = 0;
	Min = 0;
	Max = 0;
	Alelos = "";
}

//----------------------------------------------------------------------------------------------
// Construtor do Gene - Um Gene � uma string de 0's e 1's que codificam um valor qualquer
//----------------------------------------------------------------------------------------------
Gene::Gene(const int &Tam, const float &Mn, const float &Mx){
int i;
Singleton *S = S->Instance();

	Tamanho = Tam;
	Min = Mn;
	Max = Mx;
	Alelos.resize(Tam);

	for (i = 0; i < Tam; ++i){
		if (S->Rnd->IRandom(1, 100) <= 50) Alelos[i] = '0';
		else Alelos[i] = '1';
	}
};

//----------------------------------------------------------------------------------------------
// Efetua o crossover do cromossomo realizando o crossover dos genes
//----------------------------------------------------------------------------------------------
void Cromossomo::Mutate(const float &TxMut){
int i;

   for (i = 0; i < NumGenes; ++i){
		Cromo[i].Mutate(TxMut);
	}
}

//----------------------------------------------------------------------------------------------
// Efetua o crossover do cromossomo realizando o crossover dos genes
//----------------------------------------------------------------------------------------------
void Cromossomo::Crossover(const float &TxCruz, const Cromossomo &Crom){
int i;

   for (i = 0; i < NumGenes; ++i){
		Cromo[i].Crossover(TxCruz, Crom.Cromo[i]);
	}
}

//----------------------------------------------------------------------------------------------
// C�lculo do Fitness do Cromossomo
//----------------------------------------------------------------------------------------------
void Cromossomo::Eval(){
int i;

   for (i = 0; i < NumGenes; ++i) Cromo[i].Eval();

   Fitness = 0.97 * exp (-((pow(Cromo[0].Valor + 3, 2.0) + pow(Cromo[1].Valor + 3, 2.0))/5)) +
             0.98 * exp (-((pow(Cromo[0].Valor + 3, 2.0) + pow(Cromo[1].Valor - 3, 2.0))/5)) +
             0.99 * exp (-((pow(Cromo[0].Valor - 3, 2.0) + pow(Cromo[1].Valor + 3, 2.0))/5)) +
             1.00 * exp (-((pow(Cromo[0].Valor - 3, 2.0) + pow(Cromo[1].Valor - 3, 2.0))/5));
}

//----------------------------------------------------------------------------------------------
// Destrutor do Cromossomo. Desaloca todos os genes criados.
//----------------------------------------------------------------------------------------------
Cromossomo::~Cromossomo(){
	Cromo.resize(0);
}

//----------------------------------------------------------------------------------------------
// Construtor do Cromossomo. Com os par�metros dos genes setados em Ctrl cria o cromossomo.
//----------------------------------------------------------------------------------------------
Cromossomo::Cromossomo(const int &NGenes, const vector<TDefGene> &Ctrl){
int i;

	NumGenes = NGenes;
	Cromo.resize(NumGenes);
	for (i = 0; i < NumGenes; ++i) Cromo[i] = Gene(Ctrl[i].Tam, Ctrl[i].Min, Ctrl[i].Max);
};

//----------------------------------------------------------------------------------------------
// Realiza a sele��o de indiv�duos da popula��o para aplicar os operadores gen�ticos
//----------------------------------------------------------------------------------------------
int Genetico::Selecao(const double &SumFit){
float Aleat, Parcela;
int i;
Singleton *S = S->Instance();

   Aleat = S->Rnd->Random() * SumFit;
	Parcela = 0;
	i = -1;

	do {
      ++i;
      Parcela += (Populacao[i].Fitness + FatorTrans);
   }while ((Parcela < Aleat) && (i < (TamPop - 1)));

	return(i);
}

//----------------------------------------------------------------------------------------------
// Realiza a evolu��o da popula��o atual. Aplicando os operadores gen�ticos.
//----------------------------------------------------------------------------------------------
void Genetico::EvolPop(){
double SumFit;
int i, TamNPop, CSel1, CSel2;
vector<Cromossomo> NPopulacao;
Singleton *S = S->Instance();

   //Inicializa vetor da nova popula��o
   NPopulacao.resize(TamPop);
	//Copia os elementos da elite
	for (i = 0; i < TamElite; ++i) NPopulacao[i] = Populacao[i];
	TamNPop = TamElite;
	//Calcula o somat�rio do Fitness - Processo de sele��o
	SumFit = 0;

	for (i = 0; i < TamPop; ++i){
		//A adi��o do fator de transla��o elimina o problema decorrente de fitness negativo
		SumFit += (Populacao[i].Fitness + FatorTrans);
	}

	//Cruza elementos da popula��o atual at� completar a nova popula��o
	while (TamNPop < TamPop){
	   //Seleciona dois indiv�duos distintos da popula��o para realizar o cruzamento
		do{
			CSel1 = Selecao(SumFit);
			CSel2 = Selecao(SumFit);
		}while (CSel1 == CSel2);

		//Cruza o indiv�duo CSel1 com CSel2
		NPopulacao[TamNPop] = Populacao[CSel1];
		NPopulacao[TamNPop].Crossover(TxCruz, Populacao[CSel2]);
		++TamNPop;

		//Se ainda couber mais um indiv�duo na nova popula��o
		if (TamNPop < TamPop){
			NPopulacao[TamNPop] = Populacao[CSel2];
			//Cruza o indiv�duo CSel2 com CSel1
			NPopulacao[TamNPop].Crossover(TxCruz, Populacao[CSel1]);
			++TamNPop;
		}
	}

	//Realiza a muta��o da nova popula��o
	for (i = TamElite; i < TamPop; ++i) NPopulacao[i].Mutate(TxMut);

	//Copiando a nova popula��o
	for (i = 0; i < TamPop; ++i) Populacao[i] = NPopulacao[i];
}
//----------------------------------------------------------------------------------------------
// Faz a avalia��o da popula��o atual, identificando o melhor indiv�duo
//----------------------------------------------------------------------------------------------
void Genetico::EvalPop(){
int i;

	++NumGer;
   ++Parada;
   for (i = 0; i < TamPop; ++i) Populacao[i].Eval();
	QuickSort(Populacao, 0, TamPop - 1);

	FatorTrans = 0;
	if (Populacao[TamPop - 1].Fitness < 0) FatorTrans = abs(Populacao[TamPop - 1].Fitness);

	if (Populacao[0].Fitness > GBest.Fitness){
		GBest = Populacao[0];
		Parada = 0;
	}
}
//----------------------------------------------------------------------------------------------
// Cria a popula��o inicial de indiv�duos
//----------------------------------------------------------------------------------------------
void Genetico::CreatePop(){
int i;

	Populacao.resize(TamPop);
	for (i = 0; i < TamPop; ++i){
		Populacao[i] = Cromossomo(NumGenes, DefCromo);
	}
};
//----------------------------------------------------------------------------------------------
// Construtor do Algoritmo Gen�tico. Prepara vari�veis de controle.
//----------------------------------------------------------------------------------------------
Genetico::Genetico(const int &TPop, const int &NGenes, const vector<TDefGene> &Ct,
						 const int &NIElite, const float &TxC, const float &TxM, const int &Ngse){

   TamPop = TPop;
	NumGenes = NGenes;
	DefCromo = Ct;
	TamElite = NIElite;
	TxCruz = TxC/100.0;
	TxMut = TxM/100.0;
	NumGerEst = Ngse;
	GBest.Fitness = -1e100;
	Parada = 0;
	NumGer = 0;
}
